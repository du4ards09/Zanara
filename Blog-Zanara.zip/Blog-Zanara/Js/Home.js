// Quando o usuário rolar a página, execute a função
window.onscroll = function() {myFunction()};

// Pegar a navbar
var navbar = document.getElementById("navbar");

// Pegar a posição do topo da navbar
var sticky = navbar.offsetTop;

// Adicionar a classe sticky na navbar quando atingir a posição de rolagem. 
// Remover "sticky" quando sair dessa posição
function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky");
  } else {
    navbar.classList.remove("sticky");
  }
}

// Verificar a posição ao carregar a página e aplicar a classe sticky se necessário
window.onload = function() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky");
  }
}
